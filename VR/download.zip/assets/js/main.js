var FireblastChoice= document.getElementById('#Fireblast-Choice');
var FocusBlastChoice= document.querySelector('#FocusBlast-Choice');
var FlamethrowerChoice= document.querySelector('#Flamethrower-Choice');
var HiddenPowerChoice= document.querySelector('#HiddenPower-Choice');


FireblastChoice.addEventListener("mouseenter", function()
  {
      alert("TEST");
  });
